--
-- PostgreSQL database dump
--

\restrict uYMcybzJq4U3LR7NYbsB2Vz8UPZaPzHa3SBw3uS1j9pjjKal58GK5KG2ba652QL

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_task_progress DROP CONSTRAINT IF EXISTS "user_task_progress_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_task_progress DROP CONSTRAINT IF EXISTS "user_task_progress_taskId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS "user_sessions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS "user_roles_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS "user_roles_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_quiz_attempts DROP CONSTRAINT IF EXISTS "user_quiz_attempts_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_quiz_attempts DROP CONSTRAINT IF EXISTS "user_quiz_attempts_assessmentId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_project_progress DROP CONSTRAINT IF EXISTS "user_project_progress_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_project_progress DROP CONSTRAINT IF EXISTS "user_project_progress_projectId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_lesson_progress DROP CONSTRAINT IF EXISTS "user_lesson_progress_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_lesson_progress DROP CONSTRAINT IF EXISTS "user_lesson_progress_lessonId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_course_progress DROP CONSTRAINT IF EXISTS "user_course_progress_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_course_progress DROP CONSTRAINT IF EXISTS "user_course_progress_courseId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_certificates DROP CONSTRAINT IF EXISTS "user_certificates_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_activities DROP CONSTRAINT IF EXISTS "user_activities_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS "projects_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public.project_comments DROP CONSTRAINT IF EXISTS "project_comments_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.project_comments DROP CONSTRAINT IF EXISTS "project_comments_projectId_fkey";
ALTER TABLE IF EXISTS ONLY public.lessons DROP CONSTRAINT IF EXISTS "lessons_courseId_fkey";
ALTER TABLE IF EXISTS ONLY public.learning_tasks DROP CONSTRAINT IF EXISTS "learning_tasks_roomId_fkey";
ALTER TABLE IF EXISTS ONLY public.learning_tasks DROP CONSTRAINT IF EXISTS "learning_tasks_prerequisiteTaskId_fkey";
ALTER TABLE IF EXISTS ONLY public.learning_rooms DROP CONSTRAINT IF EXISTS "learning_rooms_prerequisiteRoomId_fkey";
ALTER TABLE IF EXISTS ONLY public.learning_phases DROP CONSTRAINT IF EXISTS "learning_phases_prereqPhaseId_fkey";
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS "courses_phaseId_fkey";
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS "courses_instructorId_fkey";
ALTER TABLE IF EXISTS ONLY public.contents DROP CONSTRAINT IF EXISTS "contents_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public.content_interactions DROP CONSTRAINT IF EXISTS "content_interactions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.content_interactions DROP CONSTRAINT IF EXISTS "content_interactions_contentId_fkey";
ALTER TABLE IF EXISTS ONLY public.content_comments DROP CONSTRAINT IF EXISTS "content_comments_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.content_comments DROP CONSTRAINT IF EXISTS "content_comments_contentId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.assessments DROP CONSTRAINT IF EXISTS "assessments_courseId_fkey";
DROP INDEX IF EXISTS public.users_username_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public."user_task_progress_userId_taskId_key";
DROP INDEX IF EXISTS public."user_project_progress_userId_projectId_key";
DROP INDEX IF EXISTS public."user_lesson_progress_userId_lessonId_key";
DROP INDEX IF EXISTS public."user_course_progress_userId_courseId_key";
DROP INDEX IF EXISTS public."user_certificates_certificateHash_key";
DROP INDEX IF EXISTS public."user_activities_userId_createdAt_idx";
DROP INDEX IF EXISTS public.roles_name_key;
DROP INDEX IF EXISTS public.permissions_key_key;
DROP INDEX IF EXISTS public.learning_phases_order_key;
DROP INDEX IF EXISTS public."content_interactions_userId_contentId_key";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_task_progress DROP CONSTRAINT IF EXISTS user_task_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_quiz_attempts DROP CONSTRAINT IF EXISTS user_quiz_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.user_project_progress DROP CONSTRAINT IF EXISTS user_project_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.user_lesson_progress DROP CONSTRAINT IF EXISTS user_lesson_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.user_course_progress DROP CONSTRAINT IF EXISTS user_course_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.user_certificates DROP CONSTRAINT IF EXISTS user_certificates_pkey;
ALTER TABLE IF EXISTS ONLY public.user_activities DROP CONSTRAINT IF EXISTS user_activities_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.project_comments DROP CONSTRAINT IF EXISTS project_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.lessons DROP CONSTRAINT IF EXISTS lessons_pkey;
ALTER TABLE IF EXISTS ONLY public.learning_tasks DROP CONSTRAINT IF EXISTS learning_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.learning_rooms DROP CONSTRAINT IF EXISTS learning_rooms_pkey;
ALTER TABLE IF EXISTS ONLY public.learning_phases DROP CONSTRAINT IF EXISTS learning_phases_pkey;
ALTER TABLE IF EXISTS ONLY public.datasets DROP CONSTRAINT IF EXISTS datasets_pkey;
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS courses_pkey;
ALTER TABLE IF EXISTS ONLY public.contents DROP CONSTRAINT IF EXISTS contents_pkey;
ALTER TABLE IF EXISTS ONLY public.content_interactions DROP CONSTRAINT IF EXISTS content_interactions_pkey;
ALTER TABLE IF EXISTS ONLY public.content_comments DROP CONSTRAINT IF EXISTS content_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.assessments DROP CONSTRAINT IF EXISTS assessments_pkey;
ALTER TABLE IF EXISTS ONLY public.algorithms DROP CONSTRAINT IF EXISTS algorithms_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_task_progress;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.user_quiz_attempts;
DROP TABLE IF EXISTS public.user_project_progress;
DROP TABLE IF EXISTS public.user_lesson_progress;
DROP TABLE IF EXISTS public.user_course_progress;
DROP TABLE IF EXISTS public.user_certificates;
DROP TABLE IF EXISTS public.user_activities;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.project_comments;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.lessons;
DROP TABLE IF EXISTS public.learning_tasks;
DROP TABLE IF EXISTS public.learning_rooms;
DROP TABLE IF EXISTS public.learning_phases;
DROP TABLE IF EXISTS public.datasets;
DROP TABLE IF EXISTS public.courses;
DROP TABLE IF EXISTS public.contents;
DROP TABLE IF EXISTS public.content_interactions;
DROP TABLE IF EXISTS public.content_comments;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.assessments;
DROP TABLE IF EXISTS public.algorithms;
DROP TYPE IF EXISTS public."UserStatus";
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."TaskType";
DROP TYPE IF EXISTS public."SessionStatus";
DROP TYPE IF EXISTS public."RoomTier";
DROP TYPE IF EXISTS public."RoomLevel";
DROP TYPE IF EXISTS public."RoleType";
DROP TYPE IF EXISTS public."RoleStatus";
DROP TYPE IF EXISTS public."ReactionType";
DROP TYPE IF EXISTS public."ProjectStatus";
DROP TYPE IF EXISTS public."ProjectLevel";
DROP TYPE IF EXISTS public."PermissionType";
DROP TYPE IF EXISTS public."PermissionState";
DROP TYPE IF EXISTS public."DatasetStatus";
DROP TYPE IF EXISTS public."CourseStatus";
DROP TYPE IF EXISTS public."CourseLevel";
DROP TYPE IF EXISTS public."ContentType";
DROP TYPE IF EXISTS public."ContentStatus";
DROP TYPE IF EXISTS public."AuditLogType";
DROP TYPE IF EXISTS public."AssessmentType";
DROP TYPE IF EXISTS public."AssessmentStatus";
DROP TYPE IF EXISTS public."AssessmentDifficulty";
DROP TYPE IF EXISTS public."AlgorithmStatus";
DROP TYPE IF EXISTS public."AlgorithmComplexity";
DROP TYPE IF EXISTS public."AgeGroup";
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: AgeGroup; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AgeGroup" AS ENUM (
    'KIDS',
    'ABSOLUTE_BEGINNER',
    'UNDERGRADUATE',
    'POSTGRADUATE',
    'PROFESSIONAL',
    'RESEARCHER'
);


ALTER TYPE public."AgeGroup" OWNER TO amithks;

--
-- Name: AlgorithmComplexity; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AlgorithmComplexity" AS ENUM (
    'Easy',
    'Medium',
    'Hard'
);


ALTER TYPE public."AlgorithmComplexity" OWNER TO amithks;

--
-- Name: AlgorithmStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AlgorithmStatus" AS ENUM (
    'Published',
    'Draft',
    'InReview',
    'Deprecated'
);


ALTER TYPE public."AlgorithmStatus" OWNER TO amithks;

--
-- Name: AssessmentDifficulty; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AssessmentDifficulty" AS ENUM (
    'Easy',
    'Medium',
    'Hard'
);


ALTER TYPE public."AssessmentDifficulty" OWNER TO amithks;

--
-- Name: AssessmentStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AssessmentStatus" AS ENUM (
    'Published',
    'Draft',
    'InReview',
    'Archived'
);


ALTER TYPE public."AssessmentStatus" OWNER TO amithks;

--
-- Name: AssessmentType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AssessmentType" AS ENUM (
    'Quiz',
    'Assignment',
    'Test',
    'Practical'
);


ALTER TYPE public."AssessmentType" OWNER TO amithks;

--
-- Name: AuditLogType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."AuditLogType" AS ENUM (
    'user',
    'ai',
    'dataset',
    'course',
    'security'
);


ALTER TYPE public."AuditLogType" OWNER TO amithks;

--
-- Name: ContentStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."ContentStatus" AS ENUM (
    'Published',
    'Draft',
    'PendingReview',
    'Archived',
    'Rejected'
);


ALTER TYPE public."ContentStatus" OWNER TO amithks;

--
-- Name: ContentType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."ContentType" AS ENUM (
    'Course',
    'Article',
    'Tutorial',
    'Dataset',
    'Video',
    'Quiz',
    'Guide'
);


ALTER TYPE public."ContentType" OWNER TO amithks;

--
-- Name: CourseLevel; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."CourseLevel" AS ENUM (
    'Beginner',
    'Intermediate',
    'Advanced',
    'Expert'
);


ALTER TYPE public."CourseLevel" OWNER TO amithks;

--
-- Name: CourseStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."CourseStatus" AS ENUM (
    'Published',
    'Draft',
    'InReview',
    'Archived'
);


ALTER TYPE public."CourseStatus" OWNER TO amithks;

--
-- Name: DatasetStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."DatasetStatus" AS ENUM (
    'Public',
    'Private',
    'InReview',
    'Archived'
);


ALTER TYPE public."DatasetStatus" OWNER TO amithks;

--
-- Name: PermissionState; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."PermissionState" AS ENUM (
    'granted',
    'denied',
    'notSet'
);


ALTER TYPE public."PermissionState" OWNER TO amithks;

--
-- Name: PermissionType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."PermissionType" AS ENUM (
    'System',
    'Custom'
);


ALTER TYPE public."PermissionType" OWNER TO amithks;

--
-- Name: ProjectLevel; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."ProjectLevel" AS ENUM (
    'Beginner',
    'Intermediate',
    'Advanced'
);


ALTER TYPE public."ProjectLevel" OWNER TO amithks;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'Published',
    'Draft',
    'InReview',
    'Archived'
);


ALTER TYPE public."ProjectStatus" OWNER TO amithks;

--
-- Name: ReactionType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."ReactionType" AS ENUM (
    'LIKE',
    'DISLIKE',
    'NONE'
);


ALTER TYPE public."ReactionType" OWNER TO amithks;

--
-- Name: RoleStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."RoleStatus" AS ENUM (
    'Active',
    'Inactive'
);


ALTER TYPE public."RoleStatus" OWNER TO amithks;

--
-- Name: RoleType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."RoleType" AS ENUM (
    'System',
    'Custom'
);


ALTER TYPE public."RoleType" OWNER TO amithks;

--
-- Name: RoomLevel; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."RoomLevel" AS ENUM (
    'Novice',
    'Intermediate',
    'Advanced',
    'Expert'
);


ALTER TYPE public."RoomLevel" OWNER TO amithks;

--
-- Name: RoomTier; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."RoomTier" AS ENUM (
    'Free',
    'Pro'
);


ALTER TYPE public."RoomTier" OWNER TO amithks;

--
-- Name: SessionStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."SessionStatus" AS ENUM (
    'Active',
    'Idle',
    'Flagged',
    'Revoked'
);


ALTER TYPE public."SessionStatus" OWNER TO amithks;

--
-- Name: TaskType; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."TaskType" AS ENUM (
    'READ',
    'MULTIPLE_CHOICE',
    'TRUE_FALSE',
    'MATCHING',
    'DRAG_DROP',
    'ORDERING',
    'IMAGE_IDENTIFICATION',
    'IMAGE_MATCHING',
    'FILL_BLANK',
    'CODE_TASK',
    'MINI_PROJECT',
    'PUZZLE',
    'MEMORY_GAME',
    'CLASSIFICATION_GAME',
    'AI_CONCEPT_GAME',
    'SCENARIO',
    'QUIZ',
    'VIDEO_LESSON',
    'SIMULATION',
    'CHALLENGE'
);


ALTER TYPE public."TaskType" OWNER TO amithks;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."UserRole" AS ENUM (
    'Admin',
    'Manager',
    'Editor',
    'Instructor',
    'Analyst',
    'Moderator',
    'User'
);


ALTER TYPE public."UserRole" OWNER TO amithks;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: amithks
--

CREATE TYPE public."UserStatus" AS ENUM (
    'Active',
    'Inactive',
    'Pending',
    'Suspended',
    'Deleted'
);


ALTER TYPE public."UserStatus" OWNER TO amithks;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: algorithms; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.algorithms (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    complexity public."AlgorithmComplexity" NOT NULL,
    topic text NOT NULL,
    "implementationsCount" integer DEFAULT 0 NOT NULL,
    languages text[],
    status public."AlgorithmStatus" DEFAULT 'Draft'::public."AlgorithmStatus" NOT NULL,
    "iconName" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.algorithms OWNER TO amithks;

--
-- Name: assessments; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.assessments (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    type public."AssessmentType" NOT NULL,
    category text NOT NULL,
    difficulty public."AssessmentDifficulty" NOT NULL,
    "questionsCount" integer DEFAULT 0 NOT NULL,
    duration text NOT NULL,
    attempts text DEFAULT '0'::text NOT NULL,
    status public."AssessmentStatus" DEFAULT 'Draft'::public."AssessmentStatus" NOT NULL,
    "iconName" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "courseId" text
);


ALTER TABLE public.assessments OWNER TO amithks;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    target text NOT NULL,
    type public."AuditLogType" NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO amithks;

--
-- Name: content_comments; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.content_comments (
    id text NOT NULL,
    text text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "contentId" text NOT NULL
);


ALTER TABLE public.content_comments OWNER TO amithks;

--
-- Name: content_interactions; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.content_interactions (
    id text NOT NULL,
    reaction public."ReactionType" DEFAULT 'NONE'::public."ReactionType" NOT NULL,
    rating integer,
    shared boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "contentId" text NOT NULL
);


ALTER TABLE public.content_interactions OWNER TO amithks;

--
-- Name: contents; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.contents (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    type public."ContentType" NOT NULL,
    category text NOT NULL,
    "subCategory" text,
    status public."ContentStatus" DEFAULT 'Draft'::public."ContentStatus" NOT NULL,
    views text DEFAULT '0'::text NOT NULL,
    "thumbnailIcon" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "authorId" text NOT NULL
);


ALTER TABLE public.contents OWNER TO amithks;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.courses (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    level public."CourseLevel" NOT NULL,
    price text DEFAULT 'Free'::text NOT NULL,
    students text DEFAULT '0'::text NOT NULL,
    status public."CourseStatus" DEFAULT 'Draft'::public."CourseStatus" NOT NULL,
    "thumbnailIcon" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "instructorId" text NOT NULL,
    "phaseId" text
);


ALTER TABLE public.courses OWNER TO amithks;

--
-- Name: datasets; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.datasets (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    domain text NOT NULL,
    size text NOT NULL,
    format text NOT NULL,
    license text NOT NULL,
    status public."DatasetStatus" DEFAULT 'Public'::public."DatasetStatus" NOT NULL,
    downloads text DEFAULT '0'::text NOT NULL,
    "iconName" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.datasets OWNER TO amithks;

--
-- Name: learning_phases; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.learning_phases (
    id text NOT NULL,
    "order" integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    level public."CourseLevel" DEFAULT 'Beginner'::public."CourseLevel" NOT NULL,
    "prereqPhaseId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.learning_phases OWNER TO amithks;

--
-- Name: learning_rooms; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.learning_rooms (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    level public."RoomLevel" DEFAULT 'Novice'::public."RoomLevel" NOT NULL,
    tier public."RoomTier" DEFAULT 'Free'::public."RoomTier" NOT NULL,
    category text DEFAULT 'AI Foundations'::text NOT NULL,
    "estimatedTime" text DEFAULT '45 mins'::text NOT NULL,
    "xpReward" integer DEFAULT 200 NOT NULL,
    "iconName" text DEFAULT 'Brain'::text NOT NULL,
    "ageGroup" public."AgeGroup" DEFAULT 'ABSOLUTE_BEGINNER'::public."AgeGroup" NOT NULL,
    "isPublished" boolean DEFAULT true NOT NULL,
    "prerequisiteRoomId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.learning_rooms OWNER TO amithks;

--
-- Name: learning_tasks; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.learning_tasks (
    id text NOT NULL,
    "orderNumber" integer NOT NULL,
    title text NOT NULL,
    instructions text NOT NULL,
    "taskType" public."TaskType" DEFAULT 'MULTIPLE_CHOICE'::public."TaskType" NOT NULL,
    "codeSnippet" text,
    hint text,
    "questionText" text DEFAULT ''::text NOT NULL,
    options text[],
    "correctAnswer" text DEFAULT ''::text NOT NULL,
    "taskContent" jsonb,
    "correctData" jsonb,
    explanation text,
    "explanationWrong" text,
    "imageUrl" text,
    difficulty text DEFAULT 'Medium'::text NOT NULL,
    "ageGroup" public."AgeGroup" DEFAULT 'ABSOLUTE_BEGINNER'::public."AgeGroup" NOT NULL,
    "isRequired" boolean DEFAULT true NOT NULL,
    "prerequisiteTaskId" text,
    "passingScore" integer DEFAULT 100 NOT NULL,
    "xpReward" integer DEFAULT 50 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "roomId" text NOT NULL
);


ALTER TABLE public.learning_tasks OWNER TO amithks;

--
-- Name: lessons; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.lessons (
    id text NOT NULL,
    "courseId" text NOT NULL,
    "order" integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "durationMinutes" integer DEFAULT 30 NOT NULL,
    "isRequired" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lessons OWNER TO amithks;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    module text NOT NULL,
    resource text NOT NULL,
    action text NOT NULL,
    type public."PermissionType" DEFAULT 'System'::public."PermissionType" NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.permissions OWNER TO amithks;

--
-- Name: project_comments; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.project_comments (
    id text NOT NULL,
    text text NOT NULL,
    rating integer DEFAULT 5,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "projectId" text NOT NULL
);


ALTER TABLE public.project_comments OWNER TO amithks;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.projects (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category text NOT NULL,
    level public."ProjectLevel" NOT NULL,
    technologies text[],
    status public."ProjectStatus" DEFAULT 'Draft'::public."ProjectStatus" NOT NULL,
    views text DEFAULT '0'::text NOT NULL,
    price text DEFAULT 'Free'::text NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    rating double precision DEFAULT 4.9 NOT NULL,
    aim text,
    objectives text[] DEFAULT ARRAY[]::text[],
    requirements text[] DEFAULT ARRAY[]::text[],
    scope text,
    "codeFiles" jsonb,
    "thumbnailIcon" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "authorId" text NOT NULL
);


ALTER TABLE public.projects OWNER TO amithks;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.role_permissions (
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL,
    state public."PermissionState" DEFAULT 'granted'::public."PermissionState" NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO amithks;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    type public."RoleType" DEFAULT 'Custom'::public."RoleType" NOT NULL,
    "usersCount" integer DEFAULT 0 NOT NULL,
    "userPercentage" double precision DEFAULT 0 NOT NULL,
    "permissionsCount" integer DEFAULT 0 NOT NULL,
    description text NOT NULL,
    status public."RoleStatus" DEFAULT 'Active'::public."RoleStatus" NOT NULL,
    "iconName" text,
    "iconBg" text,
    "iconColor" text,
    "isProtected" boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO amithks;

--
-- Name: user_activities; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_activities (
    id text NOT NULL,
    "userId" text NOT NULL,
    "activityType" text NOT NULL,
    "durationSeconds" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_activities OWNER TO amithks;

--
-- Name: user_certificates; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_certificates (
    id text NOT NULL,
    "certificateHash" text NOT NULL,
    "trackName" text NOT NULL,
    "scorePercent" integer DEFAULT 100 NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public.user_certificates OWNER TO amithks;

--
-- Name: user_course_progress; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_course_progress (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    status public."CourseStatus" DEFAULT 'Draft'::public."CourseStatus" NOT NULL,
    "progressPercent" double precision DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.user_course_progress OWNER TO amithks;

--
-- Name: user_lesson_progress; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_lesson_progress (
    id text NOT NULL,
    "userId" text NOT NULL,
    "lessonId" text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.user_lesson_progress OWNER TO amithks;

--
-- Name: user_project_progress; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_project_progress (
    id text NOT NULL,
    "userId" text NOT NULL,
    "projectId" text NOT NULL,
    status public."ProjectStatus" DEFAULT 'Draft'::public."ProjectStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.user_project_progress OWNER TO amithks;

--
-- Name: user_quiz_attempts; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_quiz_attempts (
    id text NOT NULL,
    "userId" text NOT NULL,
    "assessmentId" text NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    passed boolean DEFAULT true NOT NULL,
    "attemptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_quiz_attempts OWNER TO amithks;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_roles (
    "userId" text NOT NULL,
    "roleId" text NOT NULL
);


ALTER TABLE public.user_roles OWNER TO amithks;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_sessions (
    id text NOT NULL,
    ip text NOT NULL,
    location text NOT NULL,
    device text NOT NULL,
    "authMethod" text DEFAULT '2FA / Password'::text NOT NULL,
    duration text DEFAULT '0m'::text NOT NULL,
    status public."SessionStatus" DEFAULT 'Active'::public."SessionStatus" NOT NULL,
    "lastActive" text DEFAULT 'Just now'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO amithks;

--
-- Name: user_task_progress; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.user_task_progress (
    id text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "userAnswer" text,
    "submittedAnswer" jsonb,
    "xpEarned" integer DEFAULT 0 NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    passed boolean DEFAULT false NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "timeSpentSec" integer DEFAULT 0 NOT NULL,
    "completedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL,
    "taskId" text NOT NULL
);


ALTER TABLE public.user_task_progress OWNER TO amithks;

--
-- Name: users; Type: TABLE; Schema: public; Owner: amithks
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    phone text,
    password text,
    avatar text,
    role public."UserRole" DEFAULT 'User'::public."UserRole" NOT NULL,
    organization text,
    status public."UserStatus" DEFAULT 'Active'::public."UserStatus" NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "lastActive" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO amithks;

--
-- Data for Name: algorithms; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.algorithms (id, name, description, category, complexity, topic, "implementationsCount", languages, status, "iconName", "updatedAt", "createdAt") FROM stdin;
alg-1	Linear & Logistic Regression	Fundamental supervised learning algorithms for regression prediction and binary classification.	Machine Learning	Easy	Regression	12	{Python,Scikit-Learn,R}	Published	TrendingUp	2026-09-30 11:40:35.517	2026-09-30 11:40:35.517
alg-2	Decision Trees & Random Forests	Tree-based ensemble method combining multiple decision trees to reduce variance.	Machine Learning	Medium	Classification	9	{Python,R,Scala}	Published	Trees	2026-09-30 11:40:35.52	2026-09-30 11:40:35.52
alg-3	Gradient Boosting (XGBoost & LightGBM)	State-of-the-art boosting algorithm sequentially building trees to minimize error.	Machine Learning	Hard	Tabular ML	8	{Python,C++,Julia}	Published	Zap	2026-09-30 11:40:35.522	2026-09-30 11:40:35.522
alg-4	Support Vector Machines (SVM)	Finds optimal hyperplanes separating data classes with maximum margin.	Machine Learning	Medium	Classification	6	{Python,C++}	Published	Shield	2026-09-30 11:40:35.524	2026-09-30 11:40:35.524
alg-5	K-Nearest Neighbors (KNN)	Instance-based non-parametric classifier predicting labels based on k closest distance metrics.	Machine Learning	Easy	Classification	10	{Python,C++}	Published	Grid	2026-09-30 11:40:35.527	2026-09-30 11:40:35.527
alg-6	Naive Bayes Classifier	Probabilistic classifier applying Bayes theorem with strong independence assumptions.	Machine Learning	Easy	NLP & Spam	8	{Python,R}	Published	MessageSquare	2026-09-30 11:40:35.529	2026-09-30 11:40:35.529
alg-7	Principal Component Analysis (PCA)	Unsupervised linear dimensionality reduction projecting high-dimensional data onto orthogonal axes.	Machine Learning	Medium	Dimensionality Reduction	7	{Python,NumPy,MATLAB}	Published	Maximize2	2026-09-30 11:40:35.531	2026-09-30 11:40:35.531
alg-8	t-SNE & UMAP	Non-linear manifold reduction techniques preserving local and global data topology.	Machine Learning	Hard	Data Visualization	6	{Python,R}	Published	Eye	2026-09-30 11:40:35.534	2026-09-30 11:40:35.534
alg-9	Multi-Layer Perceptron (MLP)	Feedforward artificial neural network with input, hidden, and output layers.	Deep Learning	Medium	Neural Networks	10	{Python,PyTorch,TensorFlow}	Published	Brain	2026-09-30 11:40:35.535	2026-09-30 11:40:35.535
alg-10	Convolutional Neural Networks (CNNs)	Deep neural networks utilizing spatial convolution filters for computer vision.	Deep Learning	Hard	Computer Vision	8	{Python,PyTorch,Keras}	Published	Image	2026-09-30 11:40:35.537	2026-09-30 11:40:35.537
alg-11	YOLO (You Only Look Once)	Single-pass real-time object detection predicting bounding boxes and class probabilities.	Deep Learning	Hard	Object Detection	9	{Python,PyTorch,C++}	Published	Target	2026-09-30 11:40:35.541	2026-09-30 11:40:35.541
alg-12	Vision Transformer (ViT)	Adapts self-attention architecture to image patches for state-of-the-art vision recognition.	Deep Learning	Hard	Computer Vision	7	{Python,PyTorch}	Published	Sparkles	2026-09-30 11:40:35.544	2026-09-30 11:40:35.544
alg-13	Generative Adversarial Networks (GANs)	Competitive training between Generator and Discriminator neural networks.	Deep Learning	Hard	Generative Models	8	{Python,PyTorch}	Published	Palette	2026-09-30 11:40:35.557	2026-09-30 11:40:35.557
alg-14	Recurrent Neural Networks (LSTMs & GRUs)	Sequential neural network architecture with memory gates for time-series and speech.	Deep Learning	Hard	Sequence Modeling	6	{Python,PyTorch}	Published	Clock	2026-09-30 11:40:35.558	2026-09-30 11:40:35.558
alg-15	U-Net Architecture	Symmetric encoder-decoder network with skip connections for biomedical image segmentation.	Deep Learning	Hard	Segmentation	5	{Python,PyTorch}	Published	Layers	2026-09-30 11:40:35.559	2026-09-30 11:40:35.559
alg-16	Transformer Self-Attention Architecture	Core mechanism of modern LLMs computing dynamic queries, keys, and values attention weights.	Generative AI	Hard	LLM Core	15	{Python,PyTorch,Transformers}	Published	Sparkles	2026-09-30 11:40:35.56	2026-09-30 11:40:35.56
alg-17	Mixture of Experts (MoE)	Sparse architecture routing tokens to specialized expert subnetworks dynamically.	Generative AI	Hard	LLM Scaling	6	{Python,PyTorch,vLLM}	Published	Cpu	2026-09-30 11:40:35.563	2026-09-30 11:40:35.563
alg-18	Retrieval-Augmented Generation (RAG)	Combines dense vector search with generative LLMs to ground responses in external documents.	Generative AI	Hard	AI Agents	12	{Python,LangChain,LlamaIndex}	Published	Database	2026-09-30 11:40:35.565	2026-09-30 11:40:35.565
alg-19	ReAct Agent Framework	Synergizes Reasoning and Acting trace loops for autonomous LLM tool execution.	Generative AI	Hard	Autonomous Agents	8	{Python,LangChain}	Published	Bot	2026-09-30 11:40:35.568	2026-09-30 11:40:35.568
alg-20	Diffusion Models (Latent Diffusion & DDPM)	Generative model iteratively denoising Gaussian noise to produce high-resolution images.	Generative AI	Hard	Image Generation	7	{Python,PyTorch,Diffusers}	Published	Palette	2026-09-30 11:40:35.572	2026-09-30 11:40:35.572
alg-21	LoRA & QLoRA Fine-Tuning	Low-Rank Adaptation freezing pretrained weights and injecting trainable rank decomposition matrices.	Generative AI	Hard	LLM Fine-Tuning	9	{Python,PEFT,BitsAndBytes}	Published	Cpu	2026-09-30 11:40:35.575	2026-09-30 11:40:35.575
alg-22	Direct Preference Optimization (DPO)	Aligns LLMs with human preferences directly using implicit reward functions.	Generative AI	Hard	Model Alignment	4	{Python,PyTorch}	Published	CheckCircle	2026-09-30 11:40:35.576	2026-09-30 11:40:35.576
alg-23	Speculative Decoding	Accelerates LLM inference using small draft models to propose candidate tokens in parallel.	Generative AI	Hard	Inference Optimization	5	{Python,C++,vLLM}	Published	Zap	2026-09-30 11:40:35.577	2026-09-30 11:40:35.577
alg-24	A* Search Algorithm	Finds shortest path using heuristic informed search functions.	Search & Graphs	Medium	Graph Search	6	{Python,C++,Java}	Published	Network	2026-09-30 11:40:35.579	2026-09-30 11:40:35.579
alg-25	Graph Convolutional Networks (GCN)	Neural networks aggregating feature representations over local graph neighborhoods.	Search & Graphs	Hard	Graph AI	7	{Python,"PyTorch Geometric"}	Published	Share2	2026-09-30 11:40:35.581	2026-09-30 11:40:35.581
alg-26	Minimax with Alpha-Beta Pruning	Decision-rule algorithm evaluating optimal moves in zero-sum games.	Search & Graphs	Medium	Game AI	5	{Python,C++}	Published	Gamepad2	2026-09-30 11:40:35.581	2026-09-30 11:40:35.581
alg-27	PageRank Algorithm	Calculates node importance in link networks via random walk stationary distribution.	Search & Graphs	Medium	Network Science	8	{Python,C++}	Published	Globe	2026-09-30 11:40:35.582	2026-09-30 11:40:35.582
alg-28	K-Means Clustering	Partitions data into K distinct clusters minimizing within-cluster variance.	Clustering	Medium	Unsupervised ML	8	{Python,R,Julia}	Published	CircleDot	2026-09-30 11:40:35.584	2026-09-30 11:40:35.584
alg-29	DBSCAN Clustering	Density-based spatial clustering identifying clusters of arbitrary shapes and noise.	Clustering	Medium	Unsupervised ML	6	{Python,Scikit-Learn}	Published	Share2	2026-09-30 11:40:35.586	2026-09-30 11:40:35.586
alg-30	Gaussian Mixture Models (GMM)	Probabilistic clustering model assuming data points are generated from mixture of Gaussians.	Clustering	Hard	Expectation Maximization	5	{Python,Scikit-Learn}	Published	Activity	2026-09-30 11:40:35.587	2026-09-30 11:40:35.587
alg-31	Hierarchical Agglomerative Clustering	Bottom-up clustering building a dendrogram tree of nested dataset merges.	Clustering	Medium	Unsupervised ML	6	{Python,R}	Published	GitMerge	2026-09-30 11:40:35.59	2026-09-30 11:40:35.59
alg-32	Deep Q-Networks (DQN)	Combines Q-learning with deep neural networks to learn optimal control policies from pixels.	Reinforcement Learning	Hard	RL Control	5	{Python,PyTorch,Gymnasium}	Published	Trophy	2026-09-30 11:40:35.591	2026-09-30 11:40:35.591
alg-33	Proximal Policy Optimization (PPO)	Policy gradient method clipping probability ratios for stable reinforcement learning.	Reinforcement Learning	Hard	RL Policy	6	{Python,Stable-Baselines3}	Published	Activity	2026-09-30 11:40:35.593	2026-09-30 11:40:35.593
alg-34	Monte Carlo Tree Search (MCTS)	Heuristic search algorithm building search trees via random rollout simulation (AlphaGo core).	Reinforcement Learning	Hard	Game AI & RL	5	{Python,C++}	Published	Compass	2026-09-30 11:40:35.595	2026-09-30 11:40:35.595
alg-35	Soft Actor-Critic (SAC)	Off-policy maximum entropy actor-critic algorithm for continuous robotic control.	Reinforcement Learning	Hard	Continuous RL	4	{Python,PyTorch}	Published	Flame	2026-09-30 11:40:35.597	2026-09-30 11:40:35.597
\.


--
-- Data for Name: assessments; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.assessments (id, name, description, type, category, difficulty, "questionsCount", duration, attempts, status, "iconName", "updatedAt", "createdAt", "courseId") FROM stdin;
asm-1	Machine Learning Basics Quiz	Test your understanding of ML basics	Quiz	AI / ML	Easy	20	20 min	1,200	Published	ClipboardCheck	2026-09-30 11:40:35.504	2026-09-30 11:40:35.504	crs-1
asm-2	Data Structures Assignment	Solve problems on arrays, stacks, queues	Assignment	Programming	Medium	10	60 min	890	Published	Code	2026-09-30 11:40:35.507	2026-09-30 11:40:35.507	\N
asm-3	Neural Networks Test	Comprehensive test on neural network architecture	Test	AI / ML	Hard	30	90 min	456	Published	Brain	2026-09-30 11:40:35.51	2026-09-30 11:40:35.51	crs-2
asm-4	Python Practical Exam	Hands-on coding exam for Python proficiency	Practical	Programming	Medium	5	120 min	650	Draft	Terminal	2026-09-30 11:40:35.512	2026-09-30 11:40:35.512	crs-3
asm-5	NLP Fundamentals Quiz	Test on text processing and language models	Quiz	AI / ML	Easy	15	15 min	320	InReview	MessageSquare	2026-09-30 11:40:35.514	2026-09-30 11:40:35.514	crs-4
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.audit_logs (id, action, target, type, "timestamp", "userId") FROM stdin;
log-1	Created new course	Machine Learning Fundamentals	course	2026-09-30 11:40:35.687	usr-2
log-2	Updated user role	sarah_johnson → Admin	user	2026-09-30 11:40:35.691	usr-1
log-3	Uploaded dataset	ImageNet Mini	dataset	2026-09-30 11:40:35.694	usr-4
log-4	Enabled 2FA	Security Settings	security	2026-09-30 11:40:35.697	usr-1
log-5	AI model inference	GPT-4 Turbo — 1,250 tokens	ai	2026-09-30 11:40:35.7	usr-3
log-6	Deleted draft course	Intro to Blockchain	course	2026-09-30 11:40:35.701	usr-1
log-7	User registration	michael_brown	user	2026-09-30 11:40:35.703	usr-5
log-8	Password reset	david_kim	security	2026-09-30 11:40:35.704	usr-7
\.


--
-- Data for Name: content_comments; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.content_comments (id, text, "createdAt", "updatedAt", "userId", "contentId") FROM stdin;
cmt-1	Outstanding deep dive into Attention mechanisms and Transformer scaling laws!	2026-09-30 11:40:36.057	2026-09-30 11:40:36.057	usr-1	cnt-1
cmt-2	Super helpful explanation of QLoRA 4-bit quantization. Highly recommended.	2026-09-30 11:40:36.059	2026-09-30 11:40:36.059	usr-2	cnt-1
\.


--
-- Data for Name: content_interactions; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.content_interactions (id, reaction, rating, shared, "createdAt", "updatedAt", "userId", "contentId") FROM stdin;
inter-1	LIKE	5	t	2026-09-30 11:40:36.051	2026-09-30 11:40:36.051	usr-1	cnt-1
inter-2	LIKE	5	f	2026-09-30 11:40:36.054	2026-09-30 11:40:36.054	usr-2	cnt-1
inter-3	LIKE	4	t	2026-09-30 11:40:36.055	2026-09-30 11:40:36.055	usr-3	cnt-1
\.


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.contents (id, title, description, type, category, "subCategory", status, views, "thumbnailIcon", "createdAt", "updatedAt", "authorId") FROM stdin;
cnt-1	Introduction to Neural Networks	A comprehensive guide to understanding neural networks from scratch	Article	AI & ML	\N	Published	2,856	Brain	2026-09-30 11:40:35.663	2026-09-30 11:40:35.663	usr-2
cnt-2	React Best Practices 2025	Modern React patterns, hooks, and performance optimization	Tutorial	Web Development	\N	Published	4,123	Code	2026-09-30 11:40:35.669	2026-09-30 11:40:35.669	usr-1
cnt-3	Data Visualization with D3.js	Create interactive charts and visualizations	Video	Data Science	\N	Draft	1,200	BarChart	2026-09-30 11:40:35.673	2026-09-30 11:40:35.673	usr-4
cnt-4	SQL Performance Tuning Guide	Optimize database queries and indexes	Guide	Database	\N	Published	3,456	Database	2026-09-30 11:40:35.676	2026-09-30 11:40:35.676	usr-3
cnt-5	LLM Fine-tuning Workshop	Step-by-step guide to fine-tune large language models	Course	AI & ML	\N	PendingReview	890	Sparkles	2026-09-30 11:40:35.685	2026-09-30 11:40:35.685	usr-8
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.courses (id, title, description, category, level, price, students, status, "thumbnailIcon", "updatedAt", "createdAt", "instructorId", "phaseId") FROM stdin;
crs-0b	Visual AI & Scratch Robotics (Grades 9–10)	Block-based programming, computer vision games, and voice recognition for middle/high schoolers.	K-12 & School	Beginner	Free	6,140	Published	Sparkles	2026-09-30 11:40:35.448	2026-09-30 11:40:35.448	usr-8	\N
crs-1b	Exploratory Data Science & Statistics	Analyze real datasets with Pandas, NumPy, and statistical hypothesis testing.	Basic Data Science	Beginner	₹999	3,890	Published	Database	2026-09-30 11:40:35.45	2026-09-30 11:40:35.45	usr-4	\N
crs-0	AI for School Kids & Young Creators (Grades 5–8)	Zero math or coding needed! Discover how robots, Siri, and ChatGPT work through fun visual games and animations.	K-12 & School	Beginner	Free	8,420	Published	Sparkles	2026-09-30 11:40:36.075	2026-09-30 11:40:35.435	usr-2	phase-1
crs-1	Python & Math Foundations for AI (Grades 11–12)	Learn Python code, data structures, vectors, and plotting charts step-by-step.	Basic Programming	Beginner	Free	5,128	Published	Code	2026-09-30 11:40:36.076	2026-09-30 11:40:35.449	usr-8	phase-1
crs-2	Classical Machine Learning & Scikit-Learn (Undergrad)	Build prediction models using Linear Regression, Decision Trees, SVMs, and Random Forests.	Machine Learning	Intermediate	₹1,999	3,256	Published	Brain	2026-09-30 11:40:36.077	2026-09-30 11:40:35.452	usr-2	phase-2
crs-3	Deep Learning & Neural Networks with PyTorch	Train multi-layer perceptrons, CNNs for computer vision, and LSTMs for time series.	Deep Learning	Intermediate	₹3,999	2,842	Published	Network	2026-09-30 11:40:36.077	2026-09-30 11:40:35.453	usr-1	phase-2
crs-4	Generative AI, LLMs & Enterprise RAG Architecture	Master Transformers, Self-Attention math, Vector Databases (Pinecone/FAISS), and Production RAG Agents.	Generative AI	Advanced	₹5,999	1,456	Published	MessageSquare	2026-09-30 11:40:36.078	2026-09-30 11:40:35.457	usr-2	phase-3
crs-5	LoRA Fine-Tuning & MLOps Deployment (Senior Architect)	Fine-tune open LLMs (Llama-3), quantization with BitsAndBytes, vLLM serving, and GPU clusters.	MLOps & Systems	Advanced	₹7,999	986	Published	Cpu	2026-09-30 11:40:36.079	2026-09-30 11:40:35.459	usr-1	phase-5
crs-6	Autonomous Multi-Agent Systems & LangGraph Workflows	Build stateful multi-agent systems with LangGraph, Model Context Protocol (MCP), human-in-the-loop approvals, and asynchronous tool execution.	Agentic AI	Advanced	₹8,499	2,340	Published	Bot	2026-09-30 11:40:36.08	2026-09-30 11:40:35.462	usr-2	phase-4
crs-7	High-Throughput LLM Inference Serving (vLLM, TensorRT & Triton)	Optimize GPU memory with PagedAttention, KV-Cache compression, FP8/FP4 quantization, and production Triton Inference clusters.	AI Infrastructure	Advanced	₹9,999	1,890	Published	Cpu	2026-09-30 11:40:36.081	2026-09-30 11:40:35.464	usr-1	phase-5
crs-8	Enterprise GraphRAG & Hybrid Knowledge Retrieval	Eliminate LLM hallucinations by fusing Neo4j knowledge graphs with hybrid BM25 and dense vector embeddings with Cohere re-ranking.	Generative AI	Advanced	₹7,499	1,620	Published	Network	2026-09-30 11:40:36.081	2026-09-30 11:40:35.466	usr-2	phase-4
crs-9	Vision-Language Models, Multimodal AI & YOLOv11 Real-Time Vision	Fine-tune CLIP and LLaVA multimodal models, real-time YOLOv11 object segmentation, and agricultural leaf pest diagnosis.	Computer Vision	Advanced	₹6,999	2,150	Published	Activity	2026-09-30 11:40:36.082	2026-09-30 11:40:35.467	usr-8	phase-3
crs-10	AI Safety, Prompt Injection Defense & Enterprise Guardrails	Master OWASP Top 10 for LLMs, adversarial red-teaming, NVIDIA NeMo Guardrails, and automated compliance auditing.	Security & Governance	Advanced	₹7,999	1,420	Published	Shield	2026-09-30 11:40:36.082	2026-09-30 11:40:35.469	usr-2	phase-6
crs-11	Edge AI, Small Language Models (SLMs) & On-Device Deployment	Deploy quantized Phi-4 and Qwen-2.5 models on Apple Silicon, Jetson, and mobile devices using ONNX Runtime, GGUF, and WebGPU.	Edge & Mobile AI	Intermediate	₹5,999	2,810	Published	Smartphone	2026-09-30 11:40:36.083	2026-09-30 11:40:35.47	usr-1	phase-4
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.datasets (id, name, description, category, domain, size, format, license, status, downloads, "iconName", "updatedAt", "createdAt") FROM stdin;
ds-1	ImageNet Mini	Subset of ImageNet for educational use	Computer Vision	AI & ML	12.4 GB	Parquet	CC BY 4.0	Public	4,200	Image	2026-09-30 11:40:35.497	2026-09-30 11:40:35.497
ds-2	CIFAR-10	Object recognition dataset (10 classes)	Computer Vision	AI & ML	162 MB	Binary	MIT	Public	6,800	Layers	2026-09-30 11:40:35.499	2026-09-30 11:40:35.499
ds-3	IMDB Reviews	Movie reviews for sentiment analysis	NLP	AI & ML	84 MB	CSV	Apache 2.0	Public	3,200	FileText	2026-09-30 11:40:35.5	2026-09-30 11:40:35.5
ds-4	COVID-19 Clinical Trials	Clinical trial data from WHO	Healthcare	Medical	2.1 GB	JSON	CC BY-NC	Private	1,100	Heart	2026-09-30 11:40:35.502	2026-09-30 11:40:35.502
ds-5	NYC Taxi Trips	NYC taxi trip records (2019-2023)	Transportation	Urban Analytics	48 GB	Parquet	Open Data	Public	2,500	Car	2026-09-30 11:40:35.502	2026-09-30 11:40:35.502
\.


--
-- Data for Name: learning_phases; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.learning_phases (id, "order", title, description, level, "prereqPhaseId", "createdAt", "updatedAt") FROM stdin;
phase-1	1	Stage 1: AI Foundations & Intelligent Agents	Master symbolic rule-based AI, agent environments (PEAS), uninformed/informed search (A*), logic, and expert systems.	Beginner	\N	2026-09-30 11:40:36.062	2026-09-30 11:40:36.062
phase-2	2	Stage 2: Machine Learning & Statistical Modeling	Supervised classification/regression, Random Forests, XGBoost, K-Means clustering, PCA, bias-variance tradeoff, and SHAP interpretability.	Intermediate	phase-1	2026-09-30 11:40:36.065	2026-09-30 11:40:36.065
phase-3	3	Stage 3: Deep Learning & PyTorch Networks	Multi-layer perceptrons, backpropagation chain rule, SGD/AdamW optimizers, CNN spatial vision, LSTM sequence models, and Transformer self-attention math.	Intermediate	phase-2	2026-09-30 11:40:36.067	2026-09-30 11:40:36.067
phase-4	4	Stage 4: Generative AI, LLMs & Autonomous Agents	BPE tokenization, pretraining vs alignment (DPO), prompt engineering, enterprise RAG vector DBs (FAISS/Qdrant), 4-bit QLoRA PEFT, and ReAct tool-calling agents.	Advanced	phase-3	2026-09-30 11:40:36.069	2026-09-30 11:40:36.069
phase-5	5	AI Systems Design & High-Performance Inference	Design large-scale GPU clusters, vLLM serving engines, PagedAttention, and ONNX MLOps deployment.	Expert	phase-4	2026-09-30 11:40:36.071	2026-09-30 11:40:36.071
phase-6	6	Expert Research & AI Frontiers	Multimodal representations, state-space models (Mamba), custom CUDA kernel optimization, and research leadership.	Expert	phase-5	2026-09-30 11:40:36.072	2026-09-30 11:40:36.072
\.


--
-- Data for Name: learning_rooms; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.learning_rooms (id, title, description, level, tier, category, "estimatedTime", "xpReward", "iconName", "ageGroup", "isPublished", "prerequisiteRoomId", "createdAt", "updatedAt") FROM stdin;
room-0	The Math & Human Brain Behind AI	Discover how the human brain inspires neural networks, how matrices and calculus power AI, and real-time application examples.	Novice	Free	Foundations & Math	30 mins	200	Brain	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.955	2026-09-30 11:40:35.955
room-1	What is AI? (Novice Foundations)	Zero background required. Understand the difference between AI, Machine Learning, Deep Learning, and Generative AI.	Novice	Free	AI Foundations	30 mins	200	Sparkles	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.96	2026-09-30 11:40:35.96
room-2	Python Essentials for AI Beginners	Learn variables, lists, NumPy arrays, and Pandas DataFrames with interactive code checks.	Novice	Free	Programming	45 mins	250	Code	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.962	2026-09-30 11:40:35.962
room-3	Classical Machine Learning & Scikit-Learn	Build your first prediction model using Linear Regression and Decision Trees.	Intermediate	Free	Machine Learning	1 hour	350	Cpu	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.967	2026-09-30 11:40:35.967
room-4	Deep Learning & PyTorch Neural Networks	Understand neurons, backpropagation, and build a multi-layer perceptron in PyTorch.	Advanced	Pro	Deep Learning	1.5 hours	500	Layers	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.971	2026-09-30 11:40:35.971
room-basic-tools	Everyday AI Tools & Creative Prompting for Students (5-Min Modules)	Zero code required. Explore ChatGPT, Midjourney, Claude, ElevenLabs, and visual AI games.	Novice	Free	School & Everyday AI	20 mins	200	Sparkles	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.974	2026-09-30 11:40:35.974
room-5	Generative AI, RAG & Vector Databases	Master Retrieval-Augmented Generation, embeddings, Pinecone/FAISS, and building LLM agents.	Expert	Pro	Generative AI	2 hours	750	Zap	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.977	2026-09-30 11:40:35.977
room-adv-transformers	Deep Transformers Architecture, QKV Math & LoRA Systems	In-depth Scaled Dot-Product Attention, GPU memory tiling, 4-bit QLoRA, and FlashAttention.	Expert	Pro	Advanced Generative Systems	2.5 hours	900	Cpu	ABSOLUTE_BEGINNER	t	\N	2026-09-30 11:40:35.978	2026-09-30 11:40:35.978
\.


--
-- Data for Name: learning_tasks; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.learning_tasks (id, "orderNumber", title, instructions, "taskType", "codeSnippet", hint, "questionText", options, "correctAnswer", "taskContent", "correctData", explanation, "explanationWrong", "imageUrl", difficulty, "ageGroup", "isRequired", "prerequisiteTaskId", "passingScore", "xpReward", "createdAt", "updatedAt", "roomId") FROM stdin;
task-001	1	Task 1: The Human Brain vs Artificial Neural Networks	Biological neurons have Dendrites (Inputs), Synapses (Synaptic Weight multipliers), and Soma (Cell Body Summation). Artificial Neural Networks mimic this exact biological structure using mathematical weights and activation functions!	MULTIPLE_CHOICE	# Biological Neuron equivalent in Python\ninputs = [0.8, 0.5] # Dendrites\nweights = [1.5, -0.8] # Synaptic weights\nbias = 0.2\n\n# Soma Summation\nz = sum(i * w for i, w in zip(inputs, weights)) + bias\nprint("Neuron Output (Soma):", z)	Dendrites receive inputs, Synapses weight signals, and the Cell Body sums them up.	In an Artificial Neural Network, what biological component corresponds to Feature Inputs?	{Dendrites,"Axon Terminal","Myelin Sheath","Blood Vessels"}	Dendrites	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:35.983	2026-09-30 11:40:35.983	room-0
task-002	2	Task 2: Linear Algebra & Matrix Multiplication in AI	Every Neural Network layer performs Matrix Multiplication (Y = W · X + B). Tensors (multi-dimensional matrices) allow GPUs to process millions of calculations simultaneously in parallel.	MULTIPLE_CHOICE	import numpy as np\n# Inputs X (batch of 2 samples, 3 features)\nX = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])\n# Weight Matrix W (3 inputs -> 2 neurons)\nW = np.array([[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]])\n\n# Matrix Multiplication\nY = np.dot(X, W)\nprint("Layer Output Matrix Shape:", Y.shape)	Matrix Multiplication (W · X) computes all neuron outputs at once.	What mathematical operation enables GPUs to compute neuron layers in parallel?	{"Matrix Multiplication (Dot Product)","Polynomial Long Division","Prime Factorization","String Concatenation"}	Matrix Multiplication (Dot Product)	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:35.989	2026-09-30 11:40:35.989	room-0
task-003	3	Task 3: Calculus & How AI Learns (Backpropagation)	AI learns by minimizing Error Loss. Derivatives and Gradients (Calculus) calculate the slope of error. Gradient Descent updates weights (W = W - alpha * Gradient) using the Calculus Chain Rule.	MULTIPLE_CHOICE	# Gradient Descent Weight Update in Calculus\nlearning_rate = 0.01\nweight = 5.0 # Initial weight\ngradient = 2.4 # Partial derivative dLoss/dWeight\n\n# Calculus update step\nnew_weight = weight - (learning_rate * gradient)\nprint("Updated Weight:", new_weight)	Gradients indicate the direction to adjust weights to decrease error.	Which mathematical field calculates error slopes to update neural network weights?	{"Calculus & Partial Derivatives","Euclidean Geometry",Combinatorics,"Set Theory"}	Calculus & Partial Derivatives	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:35.994	2026-09-30 11:40:35.994	room-0
task-004	4	Task 4: Real-Time AI Applications (Self-Driving Cars & Medical MRI)	Real-time AI powers Tesla/Waymo self-driving vision (CNN camera processing in under 10ms), hospital MRI tumor detection, and Siri real-time voice synthesis.	MULTIPLE_CHOICE	# Real-Time Sensor Processing Loop\ndef process_frame(camera_feed):\n    bounding_boxes = cnn_model.detect(camera_feed)\n    if any(box.type == "pedestrian" for box in bounding_boxes):\n        return "Emergency Brake Active"\n    return "Clear Way"	Real-time AI processes vision and sensor inputs in milliseconds.	What is a critical requirement for AI models running in self-driving cars?	{"Real-time low latency processing (<10ms)","Manual offline calculation","Printing output on paper","Weekly batch updates"}	Real-time low latency processing (<10ms)	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:35.999	2026-09-30 11:40:35.999	room-0
task-005	5	Task 5: Layer-by-Layer AI Architecture (Which Layer Does What?)	1. Input Layer: Converts raw text to Token IDs. 2. Embedding Layer: Converts Token IDs to dense vectors. 3. Hidden Layers: Performs Matrix Multiplication (W · X + B) and Self-Attention. 4. Hardware Layer: Executes FP16/INT4 binary bitstreams on CUDA cores. 5. Output LM Head Layer: Computes Softmax probabilities over vocabulary words.	MULTIPLE_CHOICE	# Layer-by-Layer Forward Pass in PyTorch\ntoken_ids = tokenizer("AI is amazing")           # 1. Input Layer\nembeddings = embedding_layer(token_ids)         # 2. Embedding Layer\nhidden_states = transformer_hidden_layers(embeddings) # 3. Hidden Layers (W*X + B)\nlogits = lm_head_output_layer(hidden_states)     # 5. Output LM Head Layer\nprobs = torch.softmax(logits, dim=-1)             # Final Softmax Probabilities	Token IDs are converted to dense vectors in the Embedding Layer, processed in Hidden Layers, and converted to probabilities in the Output LM Head Layer.	In which AI model layer is text converted from integer Token IDs into dense floating-point vectors?	{"Embedding Layer","Output LM Head Layer","Softmax Activation Layer","Storage Hardware Disk"}	Embedding Layer	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.003	2026-09-30 11:40:36.003	room-0
task-101	1	Task 1: What is Artificial Intelligence?	Artificial Intelligence (AI) refers to systems or machines that mimic human intelligence to perform tasks and iteratively improve based on the information they collect.	MULTIPLE_CHOICE	# Example AI Decision Logic\ndef classify_number(n):\n    return "Positive" if n > 0 else "Non-Positive"	AI encompasses Machine Learning and Deep Learning as subfields.	Which of the following is a subfield of Artificial Intelligence?	{"Machine Learning","Quantum Hardware","Raw Memory Storage","Optical Disks"}	Machine Learning	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.009	2026-09-30 11:40:36.009	room-1
task-102	2	Task 2: AI vs Machine Learning vs Deep Learning	Machine Learning is a subset of AI where systems learn from data without being explicitly programmed. Deep Learning uses multi-layered Neural Networks.	MULTIPLE_CHOICE	import numpy as np\ndata = np.array([1, 2, 3, 4, 5])\nprint("Mean:", data.mean())	Neural Networks drive Deep Learning.	What technology drives Deep Learning models?	{"Multi-Layer Neural Networks","Relational Databases","Hard Drives","SVG Graphics"}	Multi-Layer Neural Networks	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.014	2026-09-30 11:40:36.014	room-1
task-103	3	Task 3: Generative AI & Large Language Models	Generative AI creates new content (text, images, audio, code) based on patterns learned from vast training datasets.	MULTIPLE_CHOICE	# Prompting an AI Model\nprompt = "Explain quantum computing in simple terms"\nresponse = ai_model.generate(prompt)	Generative AI produces original outputs.	What is the primary capability of Generative AI?	{"Generating new original content","Formatting disk drives","Counting spreadsheet rows","Replacing motherboard chips"}	Generating new original content	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.018	2026-09-30 11:40:36.018	room-1
task-bt-1	1	Task 1: Talking to AI — The Art of Prompt Crafting (3-Min Lesson)	A prompt is the instruction or question you give to an AI model like ChatGPT or Claude. Giving clear roles, context, and examples gets the best results!	MULTIPLE_CHOICE	# Good Prompt Structure:\n# 1. Role: "You are a friendly biology teacher"\n# 2. Context: "I am preparing for a 7th-grade science quiz"\n# 3. Request: "Explain photosynthesis with a funny emoji analogy"	Clear instructions and context lead to accurate AI answers.	Which prompt technique produces the highest quality answers from an AI assistant?	{"Providing clear context, role, and constraints","Typing a single random word","Leaving the prompt box blank","Writing in binary numbers"}	Providing clear context, role, and constraints	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.025	2026-09-30 11:40:36.025	room-basic-tools
task-bt-2	2	Task 2: Visual AI — Generating Art from Natural Language	Tools like Midjourney, DALL-E, and Stable Diffusion turn text descriptions into realistic paintings, logos, and 3D scenes using Diffusion algorithms.	MULTIPLE_CHOICE	# Visual Diffusion Prompt Example:\n# "A friendly golden retriever wearing an astronaut helmet on Mars, Pixar 3D style, cinematic lighting"	Diffusion models generate images by turning random noise into structured visuals.	What kind of AI tool generates images and digital art from text descriptions?	{"Text-to-Image Diffusion Models","Barcode Scanners","Network Cable Routers","Spreadsheet Formulas"}	Text-to-Image Diffusion Models	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	50	2026-09-30 11:40:36.034	2026-09-30 11:40:36.034	room-basic-tools
task-at-1	1	Task 1: Scaled Dot-Product Attention & Matrix Projections (4-Min Deep Dive)	Self-Attention projects input embeddings into Query (Q), Key (K), and Value (V) matrices. The dot product Q · Kᵀ is scaled by 1/√d_k to prevent vanishing softmax gradients.	MULTIPLE_CHOICE	import torch\nimport math\n\ndef scaled_dot_product_attention(Q, K, V):\n    d_k = Q.size(-1)\n    scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(d_k)\n    attention_weights = torch.softmax(scores, dim=-1)\n    return torch.matmul(attention_weights, V), attention_weights	Dividing by sqrt(d_k) stabilizes the variance of large dot products.	Why is the query-key dot product matrix divided by √d_k in Transformers?	{"To stabilize variance and avoid vanishing gradients in Softmax","To convert matrices into integers","To erase all memory caches","To invert the neural weights"}	To stabilize variance and avoid vanishing gradients in Softmax	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	100	2026-09-30 11:40:36.038	2026-09-30 11:40:36.038	room-adv-transformers
task-at-2	2	Task 2: LoRA Weight Decomposition (ΔW = B · A)	Low-Rank Adaptation freezes base weights W0 (d × d) and represents updates as ΔW = B · A where B is (d × r) and A is (r × d) with rank r ≪ d, reducing trainable parameters by 99%.	MULTIPLE_CHOICE	# LoRA Forward Pass: h = W0*x + (alpha / r) * B * A * x\nimport torch.nn as nn\nclass LoRALinear(nn.Module):\n    def __init__(self, in_features, out_features, r=8, alpha=16):\n        super().__init__()\n        self.A = nn.Parameter(torch.randn(r, in_features))\n        self.B = nn.Parameter(torch.zeros(out_features, r))\n        self.scaling = alpha / r	LoRA decomposes weight updates into two low-rank matrices A and B.	In LoRA fine-tuning, how are parameter updates ΔW structured?	{"Product of two low-rank matrices (B × A where rank r ≪ d)","Re-training all model layers from scratch","Converting all weights to single precision FP64","Deleting half of the transformer layers"}	Product of two low-rank matrices (B × A where rank r ≪ d)	\N	\N	\N	\N	\N	Medium	ABSOLUTE_BEGINNER	t	\N	100	100	2026-09-30 11:40:36.042	2026-09-30 11:40:36.042	room-adv-transformers
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.lessons (id, "courseId", "order", title, description, "durationMinutes", "isRequired", "createdAt", "updatedAt") FROM stdin;
les-1	crs-0	1	Introduction to AI Concepts & Mental Models	Visual introduction to AI, Machine Learning, and Neural Networks.	45	t	2026-09-30 11:40:36.085	2026-09-30 11:40:36.085
les-2	crs-0	2	Understanding Data, Features, and Predictions	How computers see tables, images, and text features.	60	t	2026-09-30 11:40:36.086	2026-09-30 11:40:36.086
les-3	crs-1	1	Python Syntax & NumPy Matrix Basics	Writing Python scripts and operating on multi-dimensional matrices.	90	t	2026-09-30 11:40:36.087	2026-09-30 11:40:36.087
les-4	crs-1	2	Linear Algebra & Calculus for Optimization	Slopes, vectors, gradients, and loss function landscapes.	120	t	2026-09-30 11:40:36.088	2026-09-30 11:40:36.088
les-5	crs-2	1	Supervised Learning & Regression Models	Linear regression, cost functions, and polynomial fitting.	150	t	2026-09-30 11:40:36.089	2026-09-30 11:40:36.089
les-6	crs-2	2	Decision Trees, Ensembles, and Random Forests	Tree splitting rules, entropy, Gini impurity, and boosting.	180	t	2026-09-30 11:40:36.091	2026-09-30 11:40:36.091
les-7	crs-3	1	PyTorch Tensors, Autograd, and Multi-Layer Perceptrons	Building neural network computational graphs in PyTorch.	240	t	2026-09-30 11:40:36.092	2026-09-30 11:40:36.092
les-8	crs-3	2	Convolutional Neural Networks (CNNs) & Image Vision	Spatial convolutions, pooling layers, and ResNet architectures.	300	t	2026-09-30 11:40:36.093	2026-09-30 11:40:36.093
les-9	crs-4	1	Self-Attention & Transformer Architecture Deep Dive	Query-Key-Value attention math, positional encodings, and multi-head scaling.	320	t	2026-09-30 11:40:36.093	2026-09-30 11:40:36.093
les-10	crs-4	2	Vector Databases, Embeddings, and Enterprise RAG	Building semantic search engines with Pinecone, Qdrant, and LangChain.	280	t	2026-09-30 11:40:36.094	2026-09-30 11:40:36.094
les-17	crs-9	1	Vision Transformers (ViT) & Multimodal Alignment	Cross-attention fusion with CLIP, LLaVA, and SigLIP architectures.	290	t	2026-09-30 11:40:36.095	2026-09-30 11:40:36.095
les-18	crs-9	2	Real-time Object Detection with YOLOv11 & TensorRT	Anchor-free bounding boxes, non-max suppression, and edge inference.	310	t	2026-09-30 11:40:36.095	2026-09-30 11:40:36.095
les-13	crs-6	1	LangGraph State Machines & Tool Integration	Cyclic graphs, checkpointing, and Model Context Protocol (MCP) integrations.	330	t	2026-09-30 11:40:36.096	2026-09-30 11:40:36.096
les-14	crs-6	2	Autonomous Multi-Agent Collaboration Swarms	Supervisor and hierarchical multi-agent teams with human approval gates.	350	t	2026-09-30 11:40:36.097	2026-09-30 11:40:36.097
les-15	crs-8	1	Entity Knowledge Graphs with Neo4j & Cypher	Extracting knowledge triples and constructing domain graphs for RAG.	290	t	2026-09-30 11:40:36.097	2026-09-30 11:40:36.097
les-16	crs-8	2	Hybrid Dense-Sparse Vector Retrieval & Reranking	Fusing BM25 keyword matching with dense vectors and Cohere cross-encoders.	310	t	2026-09-30 11:40:36.098	2026-09-30 11:40:36.098
les-21	crs-11	1	Quantizing Small Language Models (SLMs) with GGUF & ONNX	4-bit AWQ and GGUF quantization for Phi-4, Gemma-2, and Qwen-2.5.	260	t	2026-09-30 11:40:36.099	2026-09-30 11:40:36.099
les-22	crs-11	2	On-Device Mobile AI Inference with CoreML & WebGPU	Running offline neural models in browser and edge hardware.	280	t	2026-09-30 11:40:36.1	2026-09-30 11:40:36.1
les-11	crs-5	1	LoRA & QLoRA Parameter Efficient Fine-Tuning	Fine-tuning LLaMA models using rank decomposition matrices.	360	t	2026-09-30 11:40:36.1	2026-09-30 11:40:36.1
les-12	crs-5	2	Distributed GPU Inference with vLLM & ONNX	Model quantization, PagedAttention, and high-throughput serving.	400	t	2026-09-30 11:40:36.101	2026-09-30 11:40:36.101
les-19	crs-7	1	High-Throughput Serving with PagedAttention & vLLM	Dynamic batching, KV-cache sharing, and continuous batching architectures.	380	t	2026-09-30 11:40:36.101	2026-09-30 11:40:36.101
les-20	crs-7	2	Triton Inference Server & TensorRT-LLM Acceleration	Serving FP8/FP4 models on Kubernetes with sub-10ms latency SLAs.	420	t	2026-09-30 11:40:36.102	2026-09-30 11:40:36.102
les-23	crs-10	1	OWASP Top 10 for LLMs & Jailbreak Defense	Simulating prompt injections, indirect injections, and safety jailbreaks.	300	t	2026-09-30 11:40:36.103	2026-09-30 11:40:36.103
les-24	crs-10	2	NVIDIA NeMo Guardrails & Enterprise Compliance	Topical rails, execution safety, and automated hallucination mitigations.	320	t	2026-09-30 11:40:36.104	2026-09-30 11:40:36.104
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.permissions (id, key, name, module, resource, action, type, description, "createdAt", "updatedAt") FROM stdin;
perm-1	users.read	View Users	User Management	Users	Read	System	\N	2026-09-30 11:40:35.623	2026-09-30 11:40:35.623
perm-2	users.create	Create Users	User Management	Users	Create	System	\N	2026-09-30 11:40:35.63	2026-09-30 11:40:35.63
perm-3	users.update	Update Users	User Management	Users	Update	System	\N	2026-09-30 11:40:35.633	2026-09-30 11:40:35.633
perm-4	users.delete	Delete Users	User Management	Users	Delete	System	\N	2026-09-30 11:40:35.634	2026-09-30 11:40:35.634
perm-5	courses.read	View Courses	Content	Courses	Read	System	\N	2026-09-30 11:40:35.635	2026-09-30 11:40:35.635
perm-6	courses.create	Create Courses	Content	Courses	Create	System	\N	2026-09-30 11:40:35.636	2026-09-30 11:40:35.636
perm-7	courses.update	Update Courses	Content	Courses	Update	System	\N	2026-09-30 11:40:35.638	2026-09-30 11:40:35.638
perm-8	courses.delete	Delete Courses	Content	Courses	Delete	System	\N	2026-09-30 11:40:35.641	2026-09-30 11:40:35.641
perm-9	analytics.read	View Analytics	Analytics	Analytics	Read	System	\N	2026-09-30 11:40:35.645	2026-09-30 11:40:35.645
perm-10	settings.manage	Manage Settings	Administration	Settings	Manage	System	\N	2026-09-30 11:40:35.647	2026-09-30 11:40:35.647
perm-11	roles.manage	Manage Roles	Administration	Roles	Manage	System	\N	2026-09-30 11:40:35.648	2026-09-30 11:40:35.648
perm-12	datasets.read	View Datasets	Data	Datasets	Read	System	\N	2026-09-30 11:40:35.651	2026-09-30 11:40:35.651
perm-13	datasets.create	Create Datasets	Data	Datasets	Create	Custom	\N	2026-09-30 11:40:35.655	2026-09-30 11:40:35.655
perm-14	assessments.read	View Assessments	Content	Assessments	Read	System	\N	2026-09-30 11:40:35.658	2026-09-30 11:40:35.658
perm-15	assessments.create	Create Assessments	Content	Assessments	Create	System	\N	2026-09-30 11:40:35.659	2026-09-30 11:40:35.659
perm-16	audit.read	View Audit Logs	Administration	Audit Logs	Read	System	\N	2026-09-30 11:40:35.66	2026-09-30 11:40:35.66
\.


--
-- Data for Name: project_comments; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.project_comments (id, text, rating, "createdAt", "updatedAt", "userId", "projectId") FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.projects (id, name, description, category, level, technologies, status, views, price, downloads, rating, aim, objectives, requirements, scope, "codeFiles", "thumbnailIcon", "updatedAt", "createdAt", "authorId") FROM stdin;
prj-1	Multimodal Medical Radiography Agent	Deploying 3D UNet and ViT models on Kubernetes to automate early cancer screening.	AI & ML	Advanced	{PyTorch,FastAPI,Kubernetes,DICOM}	Published	4,200	$49	320	4.9	Automate early detection of pulmonary nodules and chest radiography abnormalities using state-of-the-art vision transformers and 3D U-Net segmentation models.	{"Build a real-time DICOM image preprocessing and normalization pipeline.","Implement 3D U-Net for volumetric lesion segmentation.","Serve predictions via FastAPI microservices with sub-100ms inference latency.","Package containerized workloads with Helm charts for production Kubernetes deployment."}	{"Python 3.10+","PyTorch 2.1+ with CUDA 12 support","NVIDIA GPU with at least 16GB VRAM","Docker & Kubernetes cluster (Minikube or AWS EKS)"}	End-to-end production AI system incorporating DICOM ingest, GPU inference server, interactive web interface, and automated alert telemetry.	[{"path": "src/main.py", "content": "from fastapi import FastAPI, UploadFile, File\\nimport torch\\nfrom model import UNet3D\\n\\napp = FastAPI(title=\\"Medical Radiography Inference API\\")\\nmodel = UNet3D().eval()\\n\\n@app.post(\\"/api/v1/analyze\\")\\nasync def analyze_scan(file: UploadFile = File(...)):\\n    contents = await file.read()\\n    # Process DICOM bytes & compute lesion segmentation\\n    tensor = preprocess_dicom(contents)\\n    with torch.no_grad():\\n        mask, confidence = model(tensor)\\n    return {\\"lesions_detected\\": int(mask.sum()), \\"confidence_score\\": float(confidence)}", "language": "python"}, {"path": "src/model.py", "content": "import torch\\nimport torch.nn as nn\\n\\nclass UNet3D(nn.Module):\\n    def __init__(self, in_channels=1, out_channels=2):\\n        super().__init__()\\n        self.encoder = nn.Sequential(\\n            nn.Conv3d(in_channels, 64, kernel_size=3, padding=1),\\n            nn.BatchNorm3d(64),\\n            nn.ReLU(inplace=True)\\n        )\\n        self.head = nn.Conv3d(64, out_channels, kernel_size=1)\\n\\n    def forward(self, x):\\n        feat = self.encoder(x)\\n        out = self.head(feat)\\n        conf = torch.sigmoid(out.mean())\\n        return out, conf", "language": "python"}, {"path": "deploy/k8s-deployment.yaml", "content": "apiVersion: apps/v1\\nkind: Deployment\\nmetadata:\\n  name: radiography-agent-api\\nspec:\\n  replicas: 3\\n  selector:\\n    matchLabels:\\n      app: radiography-agent\\n  template:\\n    metadata:\\n      labels:\\n        app: radiography-agent\\n    spec:\\n      containers:\\n      - name: api\\n        image: nexus/radiography-agent:v1.2.0\\n        resources:\\n          limits:\\n            nvidia.com/gpu: 1", "language": "yaml"}]	Activity	2026-09-30 11:40:35.475	2026-09-30 11:40:35.475	usr-1
prj-2	High-Frequency Fraud Detection Pipeline	Real-time GNN inference engine analyzing 12.5M financial transactions under 15ms.	AI & ML	Advanced	{"PyTorch Geometric",vLLM,Qdrant,Kafka}	Published	3,800	$79	415	5	Detect synthetic identity theft, money laundering rings, and transaction fraud in real-time streaming pipelines using Graph Neural Networks.	{"Construct a dynamic heterogeneous financial graph from Apache Kafka event streams.","Train Relational Graph Convolutional Networks (R-GCN) for node and edge classification.","Achieve sub-15ms inference latency at 50,000 transactions per second."}	{"Python 3.11+","Apache Kafka 3.4 cluster","Qdrant Vector Database","PyTorch Geometric (PyG) 2.4+"}	Enterprise streaming analytics backend, graph feature store, model retraining service, and fraud investigator workspace UI.	[{"path": "pipeline/stream_consumer.py", "content": "from kafka import KafkaConsumer\\nimport json\\nfrom gnn_engine import FraudDetectorGNN\\n\\nconsumer = KafkaConsumer('financial_tx_stream', bootstrap_servers=['localhost:9092'])\\ndetector = FraudDetectorGNN.load_pretrained('weights/rgcn_v2.pt')\\n\\nfor msg in consumer:\\n    tx = json.loads(msg.value)\\n    risk_score = detector.evaluate_transaction(tx)\\n    if risk_score > 0.85:\\n        trigger_alert(tx, risk_score)", "language": "python"}]	Zap	2026-09-30 11:40:35.484	2026-09-30 11:40:35.484	usr-2
prj-3	Autonomous Code Refactoring Agent	Fine-tuning LLaMA 3 70B on internal repository commits for automated PR reviews.	Generative AI	Intermediate	{LangChain,LoRA,"GitHub API",FastAPI}	Published	2,900	$39	180	4.8	Build an autonomous GitHub PR review and refactoring bot that inspects diffs, detects security vulnerabilities, and suggests optimized refactored code.	{"Fine-tune LLaMA 3 70B using QLoRA parameter-efficient fine-tuning on clean codebases.","Integrate GitHub Webhooks for automated pull request events.","Generate inline review comments and automated patch suggestions."}	{"Python 3.10+","GitHub Personal Access Token / App credentials","vLLM / Ollama local LLM server"}	Developer tooling service with webhook integration, prompt engineering suite, and interactive review dashboard.	[{"path": "agent/reviewer.py", "content": "from langchain.chains import LLMChain\\nfrom langchain.prompts import PromptTemplate\\n\\nreview_prompt = PromptTemplate.from_template(\\"\\"\\"\\nAnalyze the following code diff for bugs, memory leaks, and style improvements:\\n{diff}\\n\\nProvide structured JSON suggestions:\\n\\"\\"\\")\\n\\ndef review_pull_request(diff_text: str):\\n    return review_chain.run(diff=diff_text)", "language": "python"}]	Code	2026-09-30 11:40:35.487	2026-09-30 11:40:35.487	usr-3
prj-4	Real-time Video Sentiment & Eye Tracking	Computer vision pipeline detecting facial micro-expressions and gaze direction.	Computer Vision	Beginner	{OpenCV,MediaPipe,TensorFlow,Flask}	Published	1,500	Free	512	4.7	Real-time pupil tracking and facial landmark extraction for usability testing and attention analytics.	{"Extract 468 3D facial landmarks using MediaPipe Face Mesh.","Estimate 2D gaze vectors and fixation heatmaps."}	{"Python 3.9+","Webcam / USB Camera","OpenCV & MediaPipe"}	Desktop analytics utility with real-time video preview overlay.	[{"path": "tracker/gaze.py", "content": "import cv2\\nimport mediapipe as mp\\n\\nmp_face_mesh = mp.solutions.face_mesh\\nface_mesh = mp_face_mesh.FaceMesh(max_num_faces=1)\\ncap = cv2.VideoCapture(0)\\n\\nwhile cap.isOpened():\\n    success, image = cap.read()\\n    results = face_mesh.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))\\n    # Process landmark coordinates", "language": "python"}]	Eye	2026-09-30 11:40:35.492	2026-09-30 11:40:35.492	usr-8
prj-5	Enterprise RAG Document Intelligence Platform	Multi-tenant PDF parser and hybrid dense-sparse vector search platform.	Generative AI	Advanced	{Next.js,PyTorch,Pinecone,Elasticsearch}	Published	5,100	$99	640	5	High-throughput enterprise document processing platform with hybrid BM25 + dense vector retrieval.	{"OCR optical character recognition for scanned multi-page PDFs.","Hybrid reranking using Cross-Encoders."}	{"Node.js 18+","Python 3.10+","Pinecone API Key","Elasticsearch 8+"}	Full-stack enterprise solution with multi-tenant auth, workspace sharing, and analytics.	[{"path": "src/app/api/query/route.ts", "content": "import { NextRequest, NextResponse } from 'next/server';\\n\\nexport async function POST(req: NextRequest) {\\n  const { query, workspaceId } = await req.json();\\n  // Hybrid BM25 + Dense vector search\\n  const results = await hybridSearch(query, workspaceId);\\n  return NextResponse.json({ results });\\n}", "language": "typescript"}]	Database	2026-09-30 11:40:35.495	2026-09-30 11:40:35.495	usr-4
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.role_permissions ("roleId", "permissionId", state) FROM stdin;
role-1	perm-1	granted
role-1	perm-2	granted
role-1	perm-3	granted
role-1	perm-4	granted
role-1	perm-5	granted
role-1	perm-6	granted
role-1	perm-7	granted
role-1	perm-8	granted
role-1	perm-9	granted
role-1	perm-10	granted
role-1	perm-11	granted
role-1	perm-12	granted
role-1	perm-13	granted
role-1	perm-14	granted
role-1	perm-15	granted
role-1	perm-16	granted
role-2	perm-1	granted
role-2	perm-2	granted
role-2	perm-3	granted
role-2	perm-4	granted
role-2	perm-5	granted
role-2	perm-6	granted
role-2	perm-7	granted
role-2	perm-8	granted
role-2	perm-9	granted
role-2	perm-10	granted
role-2	perm-12	granted
role-2	perm-13	granted
role-2	perm-14	granted
role-2	perm-15	granted
role-2	perm-16	granted
role-3	perm-5	granted
role-3	perm-6	granted
role-3	perm-7	granted
role-3	perm-8	granted
role-3	perm-12	granted
role-3	perm-14	granted
role-3	perm-15	granted
role-4	perm-5	granted
role-4	perm-6	granted
role-4	perm-7	granted
role-4	perm-8	granted
role-4	perm-14	granted
role-4	perm-15	granted
role-5	perm-1	granted
role-5	perm-5	granted
role-5	perm-9	granted
role-5	perm-12	granted
role-5	perm-14	granted
role-5	perm-16	granted
role-6	perm-5	granted
role-6	perm-12	granted
role-6	perm-14	granted
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.roles (id, name, type, "usersCount", "userPercentage", "permissionsCount", description, status, "iconName", "iconBg", "iconColor", "isProtected", "updatedAt", "createdAt") FROM stdin;
role-1	Super Admin	System	2	0.5	48	Full system access with all permissions	Active	Shield	bg-purple-500/20	text-purple-400	t	2026-09-30 11:40:35.599	2026-09-30 11:40:35.599
role-2	Admin	System	8	2	42	Administrative access to manage platform	Active	ShieldCheck	bg-blue-500/20	text-blue-400	t	2026-09-30 11:40:35.603	2026-09-30 11:40:35.603
role-3	Content Manager	Custom	15	3.8	28	Manage courses, articles, and learning content	Active	BookOpen	bg-emerald-500/20	text-emerald-400	f	2026-09-30 11:40:35.606	2026-09-30 11:40:35.606
role-4	Instructor	System	45	11.4	22	Create and manage courses and assessments	Active	GraduationCap	bg-amber-500/20	text-amber-400	t	2026-09-30 11:40:35.607	2026-09-30 11:40:35.607
role-5	Data Analyst	Custom	20	5.1	18	View analytics, datasets, and reports	Active	BarChart3	bg-cyan-500/20	text-cyan-400	f	2026-09-30 11:40:35.608	2026-09-30 11:40:35.608
role-6	Learner	System	300	76.1	12	Access courses, quizzes, and learning resources	Active	User	bg-slate-500/20	text-slate-400	t	2026-09-30 11:40:35.609	2026-09-30 11:40:35.609
\.


--
-- Data for Name: user_activities; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_activities (id, "userId", "activityType", "durationSeconds", "createdAt") FROM stdin;
act-usr7-0	usr-7	LESSON_LEARNING	5400	2026-09-30 11:40:36.143
act-usr7-1	usr-7	LESSON_LEARNING	9000	2026-09-29 11:40:36.143
act-usr7-2	usr-7	LESSON_LEARNING	12600	2026-09-28 11:40:36.143
act-usr7-3	usr-7	LESSON_LEARNING	16200	2026-09-27 11:40:36.143
act-usr7-4	usr-7	LESSON_LEARNING	19800	2026-09-26 11:40:36.143
act-usr7-5	usr-7	LESSON_LEARNING	23400	2026-09-25 11:40:36.143
act-usr7-6	usr-7	LESSON_LEARNING	27000	2026-09-24 11:40:36.143
act-usr1-0	usr-1	LESSON_LEARNING	7200	2026-09-30 11:40:36.143
act-usr1-1	usr-1	LESSON_LEARNING	7200	2026-09-29 11:40:36.143
act-usr1-2	usr-1	LESSON_LEARNING	7200	2026-09-28 11:40:36.143
act-usr1-3	usr-1	LESSON_LEARNING	7200	2026-09-27 11:40:36.143
\.


--
-- Data for Name: user_certificates; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_certificates (id, "certificateHash", "trackName", "scorePercent", "issuedAt", "userId") FROM stdin;
cert-1	NEXUS-CERT-948210	Generative AI & LLM Specialist Track	100	2026-09-30 11:40:36.046	usr-1
\.


--
-- Data for Name: user_course_progress; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_course_progress (id, "userId", "courseId", status, "progressPercent", "startedAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: user_lesson_progress; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_lesson_progress (id, "userId", "lessonId", completed, "completedAt") FROM stdin;
ulp-1	usr-7	les-1	t	2026-09-20 11:40:36.105
ulp-2	usr-7	les-2	t	2026-09-21 11:40:36.105
ulp-3	usr-7	les-3	t	2026-09-23 11:40:36.105
ulp-4	usr-7	les-4	t	2026-09-25 11:40:36.105
ulp-5	usr-7	les-5	t	2026-09-26 11:40:36.105
ulp-6	usr-7	les-6	t	2026-09-27 11:40:36.105
ulp-7	usr-7	les-7	t	2026-09-28 11:40:36.105
ulp-8	usr-7	les-8	t	2026-09-29 11:40:36.105
ulp-9	usr-7	les-9	t	2026-09-30 11:40:36.105
ulp-10	usr-1	les-1	t	2026-09-18 11:40:36.105
ulp-11	usr-1	les-2	t	2026-09-19 11:40:36.105
ulp-12	usr-1	les-3	t	2026-09-20 11:40:36.105
ulp-13	usr-1	les-4	t	2026-09-22 11:40:36.105
ulp-14	usr-1	les-9	t	2026-09-28 11:40:36.105
ulp-15	usr-1	les-10	t	2026-09-30 11:40:36.105
\.


--
-- Data for Name: user_project_progress; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_project_progress (id, "userId", "projectId", status, "startedAt", "completedAt") FROM stdin;
upp-1	usr-7	prj-1	Published	2026-09-30 11:40:36.128	2026-09-24 11:40:36.127
upp-2	usr-7	prj-2	Published	2026-09-30 11:40:36.14	2026-09-29 11:40:36.127
upp-3	usr-7	prj-3	InReview	2026-09-30 11:40:36.142	\N
upp-4	usr-1	prj-2	Published	2026-09-30 11:40:36.142	2026-09-25 11:40:36.127
\.


--
-- Data for Name: user_quiz_attempts; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_quiz_attempts (id, "userId", "assessmentId", score, passed, "attemptedAt") FROM stdin;
uqa-1	usr-7	asm-1	95	t	2026-09-22 11:40:36.121
uqa-2	usr-7	asm-2	88	t	2026-09-25 11:40:36.121
uqa-3	usr-7	asm-3	92	t	2026-09-28 11:40:36.121
uqa-4	usr-1	asm-1	100	t	2026-09-20 11:40:36.121
uqa-5	usr-1	asm-3	96	t	2026-09-26 11:40:36.121
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_roles ("userId", "roleId") FROM stdin;
usr-1	role-1
usr-2	role-4
usr-3	role-2
usr-4	role-3
usr-5	role-5
usr-6	role-2
usr-7	role-6
usr-8	role-4
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_sessions (id, ip, location, device, "authMethod", duration, status, "lastActive", "createdAt", "updatedAt", "userId") FROM stdin;
sess-1	192.168.1.10	Bengaluru, India	Chrome on macOS	2FA / SSO	2h 45m	Active	2 mins ago	2026-09-30 11:40:35.925	2026-09-30 11:40:35.925	usr-1
sess-2	104.28.14.2	New York, USA	Safari on macOS	Password + 2FA	1h 12m	Active	5 mins ago	2026-09-30 11:40:35.932	2026-09-30 11:40:35.932	usr-9
sess-3	82.165.197.1	Berlin, Germany	Firefox on Linux	Password	4h 20m	Idle	22 mins ago	2026-09-30 11:40:35.942	2026-09-30 11:40:35.942	usr-2
sess-4	185.220.101.4	San Francisco, USA	Chrome on Windows 11	Password	45m	Active	10 mins ago	2026-09-30 11:40:35.946	2026-09-30 11:40:35.946	usr-10
sess-5	172.56.21.9	London, UK	Edge on Windows 11	SAML SSO	6h 10m	Revoked	3 hours ago	2026-09-30 11:40:35.951	2026-09-30 11:40:35.951	usr-3
\.


--
-- Data for Name: user_task_progress; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.user_task_progress (id, completed, "userAnswer", "submittedAnswer", "xpEarned", score, passed, attempts, "startedAt", "timeSpentSec", "completedAt", "userId", "taskId") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: amithks
--

COPY public.users (id, name, username, email, phone, password, avatar, role, organization, status, "emailVerified", "lastActive", "createdAt", "updatedAt") FROM stdin;
usr-1	Sarah Johnson	sarah_johnson	sarah@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80	Admin	Nexus AI Corp	Active	t	2026-09-30 11:40:35.375	2026-09-30 11:40:35.375	2026-09-30 11:40:35.375
usr-2	Dr. Alex Morgan	alex_morgan	alex@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80	Instructor	AI Research Lab	Active	t	2026-09-30 11:40:35.404	2026-09-30 11:40:35.404	2026-09-30 11:40:35.404
usr-3	James Wilson	james_wilson	james@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80	Manager	Nexus AI Corp	Active	t	2026-09-30 11:40:35.408	2026-09-30 11:40:35.408	2026-09-30 11:40:35.408
usr-4	Emily Chen	emily_chen	emily@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80	Editor	DataScience Inc	Active	t	2026-09-30 11:40:35.412	2026-09-30 11:40:35.412	2026-09-30 11:40:35.412
usr-5	Michael Brown	michael_brown	michael@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80	Analyst	ML Ventures	Pending	f	2026-09-30 11:40:35.417	2026-09-30 11:40:35.417	2026-09-30 11:40:35.417
usr-6	Lisa Wang	lisa_wang	lisa@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80	Moderator	AI Academy	Active	t	2026-09-30 11:40:35.42	2026-09-30 11:40:35.42	2026-09-30 11:40:35.42
usr-7	David Kim	david_kim	david@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80	User	Tech Startup	Active	t	2026-09-30 11:40:35.424	2026-09-30 11:40:35.424	2026-09-30 11:40:35.424
usr-8	Anna Martinez	anna_martinez	anna@nexus.ai	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80	Instructor	University of AI	Active	t	2026-09-30 11:40:35.426	2026-09-30 11:40:35.426	2026-09-30 11:40:35.426
usr-9	John Doe	johndoe	john.doe@example.com	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80	Admin	AI Research Lab	Active	t	2026-09-30 11:40:35.428	2026-09-30 11:40:35.428	2026-09-30 11:40:35.428
usr-10	Emma Johnson	emmaj	emma.johnson@example.com	\N	$2b$10$MxYHMxMIENTgQkITjMOQOOCErPk08S8riDr9am5w/VimlZ1fe4ViG	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80	User	Data Science Team	Active	t	2026-09-30 11:40:35.43	2026-09-30 11:40:35.43	2026-09-30 11:40:35.43
\.


--
-- Name: algorithms algorithms_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.algorithms
    ADD CONSTRAINT algorithms_pkey PRIMARY KEY (id);


--
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: content_comments content_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_comments
    ADD CONSTRAINT content_comments_pkey PRIMARY KEY (id);


--
-- Name: content_interactions content_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_interactions
    ADD CONSTRAINT content_interactions_pkey PRIMARY KEY (id);


--
-- Name: contents contents_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: learning_phases learning_phases_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_phases
    ADD CONSTRAINT learning_phases_pkey PRIMARY KEY (id);


--
-- Name: learning_rooms learning_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_rooms
    ADD CONSTRAINT learning_rooms_pkey PRIMARY KEY (id);


--
-- Name: learning_tasks learning_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_tasks
    ADD CONSTRAINT learning_tasks_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: project_comments project_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.project_comments
    ADD CONSTRAINT project_comments_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY ("roleId", "permissionId");


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_activities user_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT user_activities_pkey PRIMARY KEY (id);


--
-- Name: user_certificates user_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_certificates
    ADD CONSTRAINT user_certificates_pkey PRIMARY KEY (id);


--
-- Name: user_course_progress user_course_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_course_progress
    ADD CONSTRAINT user_course_progress_pkey PRIMARY KEY (id);


--
-- Name: user_lesson_progress user_lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_lesson_progress
    ADD CONSTRAINT user_lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: user_project_progress user_project_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_project_progress
    ADD CONSTRAINT user_project_progress_pkey PRIMARY KEY (id);


--
-- Name: user_quiz_attempts user_quiz_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_quiz_attempts
    ADD CONSTRAINT user_quiz_attempts_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY ("userId", "roleId");


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_task_progress user_task_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_task_progress
    ADD CONSTRAINT user_task_progress_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: content_interactions_userId_contentId_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "content_interactions_userId_contentId_key" ON public.content_interactions USING btree ("userId", "contentId");


--
-- Name: learning_phases_order_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX learning_phases_order_key ON public.learning_phases USING btree ("order");


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: user_activities_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: amithks
--

CREATE INDEX "user_activities_userId_createdAt_idx" ON public.user_activities USING btree ("userId", "createdAt");


--
-- Name: user_certificates_certificateHash_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "user_certificates_certificateHash_key" ON public.user_certificates USING btree ("certificateHash");


--
-- Name: user_course_progress_userId_courseId_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "user_course_progress_userId_courseId_key" ON public.user_course_progress USING btree ("userId", "courseId");


--
-- Name: user_lesson_progress_userId_lessonId_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "user_lesson_progress_userId_lessonId_key" ON public.user_lesson_progress USING btree ("userId", "lessonId");


--
-- Name: user_project_progress_userId_projectId_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "user_project_progress_userId_projectId_key" ON public.user_project_progress USING btree ("userId", "projectId");


--
-- Name: user_task_progress_userId_taskId_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX "user_task_progress_userId_taskId_key" ON public.user_task_progress USING btree ("userId", "taskId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: amithks
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: assessments assessments_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT "assessments_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: content_comments content_comments_contentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_comments
    ADD CONSTRAINT "content_comments_contentId_fkey" FOREIGN KEY ("contentId") REFERENCES public.contents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_comments content_comments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_comments
    ADD CONSTRAINT "content_comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_interactions content_interactions_contentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_interactions
    ADD CONSTRAINT "content_interactions_contentId_fkey" FOREIGN KEY ("contentId") REFERENCES public.contents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_interactions content_interactions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.content_interactions
    ADD CONSTRAINT "content_interactions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contents contents_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT "contents_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: courses courses_instructorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT "courses_instructorId_fkey" FOREIGN KEY ("instructorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: courses courses_phaseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT "courses_phaseId_fkey" FOREIGN KEY ("phaseId") REFERENCES public.learning_phases(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_phases learning_phases_prereqPhaseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_phases
    ADD CONSTRAINT "learning_phases_prereqPhaseId_fkey" FOREIGN KEY ("prereqPhaseId") REFERENCES public.learning_phases(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_rooms learning_rooms_prerequisiteRoomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_rooms
    ADD CONSTRAINT "learning_rooms_prerequisiteRoomId_fkey" FOREIGN KEY ("prerequisiteRoomId") REFERENCES public.learning_rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_tasks learning_tasks_prerequisiteTaskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_tasks
    ADD CONSTRAINT "learning_tasks_prerequisiteTaskId_fkey" FOREIGN KEY ("prerequisiteTaskId") REFERENCES public.learning_tasks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_tasks learning_tasks_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.learning_tasks
    ADD CONSTRAINT "learning_tasks_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public.learning_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lessons lessons_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_comments project_comments_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.project_comments
    ADD CONSTRAINT "project_comments_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_comments project_comments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.project_comments
    ADD CONSTRAINT "project_comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_activities user_activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT "user_activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_certificates user_certificates_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_certificates
    ADD CONSTRAINT "user_certificates_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_course_progress user_course_progress_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_course_progress
    ADD CONSTRAINT "user_course_progress_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_course_progress user_course_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_course_progress
    ADD CONSTRAINT "user_course_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_lesson_progress user_lesson_progress_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_lesson_progress
    ADD CONSTRAINT "user_lesson_progress_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public.lessons(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_lesson_progress user_lesson_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_lesson_progress
    ADD CONSTRAINT "user_lesson_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_project_progress user_project_progress_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_project_progress
    ADD CONSTRAINT "user_project_progress_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_project_progress user_project_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_project_progress
    ADD CONSTRAINT "user_project_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_quiz_attempts user_quiz_attempts_assessmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_quiz_attempts
    ADD CONSTRAINT "user_quiz_attempts_assessmentId_fkey" FOREIGN KEY ("assessmentId") REFERENCES public.assessments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_quiz_attempts user_quiz_attempts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_quiz_attempts
    ADD CONSTRAINT "user_quiz_attempts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT "user_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_task_progress user_task_progress_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_task_progress
    ADD CONSTRAINT "user_task_progress_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.learning_tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_task_progress user_task_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: amithks
--

ALTER TABLE ONLY public.user_task_progress
    ADD CONSTRAINT "user_task_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uYMcybzJq4U3LR7NYbsB2Vz8UPZaPzHa3SBw3uS1j9pjjKal58GK5KG2ba652QL

